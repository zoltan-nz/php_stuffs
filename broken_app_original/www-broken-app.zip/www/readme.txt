Project Notes
This project creates a list of confectionary products

Fix the errors, configure and Rebuild this project so that it allows you to:

a) List all products in the database
b) Add products to the database
c) Remove products from the database
d) Add manufacturers to the database
e) Remove manufacturers from the database
f) Upload product images with each listing

The sql setup is contained in the sqlsetup folder.

